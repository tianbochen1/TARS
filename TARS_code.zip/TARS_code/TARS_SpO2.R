tars_spo2_directory <- function() {
  root <- getOption("TARS.spo2.root",NULL)
  if(!is.null(root)) {
    if(!is.character(root) || length(root)!=1L || is.na(root) || !dir.exists(root))
      stop("TARS.spo2.root must name the extracted script folder.")
    return(normalizePath(root,winslash="/",mustWork=TRUE))
  }
  for(frame in rev(sys.frames())) {
    path <- get0("ofile",envir=frame,inherits=FALSE)
    if(is.character(path) && length(path)==1L && !is.na(path)) {
      if(file.exists(path))
        return(dirname(normalizePath(path,winslash="/",mustWork=TRUE)))

      if(file.exists(basename(path)))
        return(normalizePath(getwd(),winslash="/",mustWork=TRUE))
    }
  }
  args <- grep("^--file=",commandArgs(trailingOnly=FALSE),value=TRUE)
  if(length(args)) {
    path <- sub("^--file=","",args[1L])
    if(file.exists(path))
      return(dirname(normalizePath(path,winslash="/",mustWork=TRUE)))
  }
  normalizePath(getwd(),winslash="/",mustWork=TRUE)
}

.TARS_SPO2_ROOT <- tars_spo2_directory()

SPO2_CFG <- list(
  records = 1:53,
  min_n = 256L,
  valid_range = c(1,100),
  tau = c(.10,.25,.50,.75,.90),
  bandwidth_c = c(.5,1,2),
  main_bandwidth_c = 2,
  mc_draws = 1000L,
  band_draws = 300L,
  average_B = c(1L,2L,5L,10L,20L,50L),
  frequency_grid_size = 257L,
  workers = 8L,
  seed = 20261009L,
  display_id = NULL,
  resume = TRUE,
  allow_download = FALSE,
  cache_dir = file.path(.TARS_SPO2_ROOT,"data"),
  output_dir = file.path(.TARS_SPO2_ROOT,"TARS_SpO2_output"),
  prefix = "SpO2",
  title = "Recorded oxygen saturation",
  series_description = "SpO$_2$ records"
)

tarsr_version <- function() "TARS-realdata-1.0"

tarsr_validate <- function(cfg) {
  whole <- function(x) is.numeric(x) && length(x)>0L && all(is.finite(x)) &&
    all(x==as.integer(x))
  stopifnot(length(cfg$tau)>=2L, all(is.finite(cfg$tau)),
    all(diff(cfg$tau)>0), all(cfg$tau>0 & cfg$tau<1),
    all(is.finite(cfg$bandwidth_c)), all(cfg$bandwidth_c>0),
    !anyDuplicated(cfg$bandwidth_c), length(cfg$main_bandwidth_c)==1L,
    cfg$main_bandwidth_c %in% cfg$bandwidth_c,
    whole(cfg$workers), length(cfg$workers)==1L, cfg$workers>=1L,
    whole(cfg$min_n), length(cfg$min_n)==1L, cfg$min_n>=32L,
    whole(cfg$mc_draws), length(cfg$mc_draws)==1L,
    whole(cfg$average_B), all(cfg$average_B>=1L), 1L %in% cfg$average_B,
    cfg$mc_draws>=10L*max(cfg$average_B),
    whole(cfg$band_draws), cfg$band_draws>=20L, cfg$band_draws<=cfg$mc_draws,
    whole(cfg$frequency_grid_size), cfg$frequency_grid_size>=33L,
    whole(cfg$seed), length(cfg$seed)==1L, cfg$seed>=0L,
    length(cfg$resume)==1L, is.logical(cfg$resume), !is.na(cfg$resume),
    length(cfg$output_dir)==1L, nzchar(cfg$output_dir),
    length(cfg$cache_dir)==1L, nzchar(cfg$cache_dir))
  cfg$average_B <- sort(unique(as.integer(cfg$average_B)))
  cfg$bandwidth_c <- sort(cfg$bandwidth_c)
  cfg
}

tarsr_download <- function(url, destination) {
  if(file.exists(destination) && file.info(destination)$size>0) return(destination)
  dir.create(dirname(destination), recursive=TRUE, showWarnings=FALSE)
  tmp <- paste0(destination,".part")
  old <- options(timeout=max(180,getOption("timeout",60)))
  on.exit({options(old); if(file.exists(tmp)) unlink(tmp)}, add=TRUE)
  error <- "Download failed"
  for(attempt in seq_len(3L)) {
    if(file.exists(tmp)) unlink(tmp)
    ok <- tryCatch({
      status <- utils::download.file(url,tmp,mode="wb",quiet=TRUE,method="libcurl")
      if(status!=0L || !file.exists(tmp) || file.info(tmp)$size==0)
        stop("Empty or unsuccessful download")
      TRUE
    },error=function(e) {error <<- conditionMessage(e); FALSE})
    if(ok) {
      if(!file.rename(tmp,destination)) stop("Cannot save downloaded file: ",destination)
      return(destination)
    }
  }
  stop(error,". Download manually to: ",normalizePath(dirname(destination),winslash="/"),
       "/",basename(destination),"\nSource: ",url)
}

tarsr_K <- function(tau) outer(tau,tau,pmin)-tcrossprod(tau)

tarsr_lags <- function(Z,H) {
  Z <- as.matrix(Z); n <- nrow(Z); d <- ncol(Z)
  G <- matrix(0,d*d,H+1L)
  for(h in 0:H) G[,h+1L] <- as.vector(crossprod(
    Z[(h+1L):n,,drop=FALSE],Z[seq_len(n-h),,drop=FALSE])/n)
  G
}

tarsr_fractional <- function(x,tau,H) {
  values <- sort(unique(x)); id <- match(x,values); n <- length(x)
  p <- tabulate(id,nbins=length(values))/n
  left <- c(0,head(cumsum(p),-1L))
  a <- sweep(outer(left,tau,function(l,t)t-l),1L,p,"/")
  a[a<0] <- 0; a[a>1] <- 1
  Z <- sweep(a[id,,drop=FALSE],2L,tau,"-")
  G <- tarsr_lags(Z,H); K <- tarsr_K(tau)
  D <- K-matrix(G[,1L],length(tau))
  list(values=values,id=id,p=p,left=left,a=a,Z=Z,G=G,D=D,K=K,
       score_mean_error=max(abs(colMeans(Z))))
}

tarsr_window <- function(G,L,correction=NULL) {
  E <- sweep(G[,seq_len(L),drop=FALSE],2L,1-(0:(L-1L))/L,"*")
  if(!is.null(correction)) E[,1L] <- E[,1L]+as.vector(correction)
  E
}

tarsr_spectrum <- function(G,omega) {
  d <- as.integer(sqrt(nrow(G)))
  F <- matrix(G[,1L],d*d,length(omega))+0i
  if(ncol(G)>1L) {
    B <- G[,-1L,drop=FALSE]
    Bt <- B[as.vector(t(matrix(seq_len(d*d),d,d))),,drop=FALSE]
    ang <- outer(seq_len(ncol(B)),omega)
    F <- F+(B+Bt)%*%cos(ang)+1i*(Bt-B)%*%sin(ang)
  }
  F/(2*pi)
}

tarsr_energy <- function(E) {
  (sum(Mod(E[,1L])^2)+2*sum(Mod(E[,-1L,drop=FALSE])^2))/(2*pi)
}

tarsr_pool_energy <- function(P,d,L,diagonal=NULL) {
  weights <- rep(c(1,rep(2,L-1L)),each=d*d)/(2*pi)
  if(!is.null(diagonal)) weights <- weights*rep(seq_len(d*d)==diagonal,L)
  colSums(P^2*weights)
}

tarsr_mcse <- function(x) if(length(x)>1L) stats::sd(x)/sqrt(length(x)) else NA_real_

tarsr_psd_min <- function(F,d) {
  min(vapply(seq_len(ncol(F)),function(i) {
    M <- matrix(F[,i],d,d); M <- (M+Conj(t(M)))/2
    min(Re(eigen(M,symmetric=TRUE,only.values=TRUE)$values))
  },numeric(1)))
}

tarsr_longest <- function(t,x,step) {
  good <- is.finite(t) & is.finite(x)
  breaks <- !good | c(TRUE,!head(good,-1L) | abs(diff(t)-step)>step*1e-6)
  groups <- cumsum(breaks)
  runs <- split(which(good),groups[good])
  if(!length(runs)) return(integer())
  runs[[which.max(lengths(runs))]]
}

tarsr_unit <- function(id,time,x,step,min_n,time_label,value_label) {
  ix <- tarsr_longest(time,x,step)
  k <- length(unique(x[ix])); n <- length(ix)
  reason <- if(n<min_n) "short_contiguous_record" else if(k<2L) "constant_record" else "included"
  audit <- data.frame(id=id,n_available=length(x),n_valid=sum(is.finite(x)),
    n_used=n,n_unique=k,missing_fraction=mean(!is.finite(x)),
    used_fraction=if(length(x)) n/length(x) else 0,
    start=if(n)time[ix[1L]] else NA_real_,end=if(n)tail(time[ix],1L) else NA_real_,
    included=reason=="included",reason=reason,stringsAsFactors=FALSE)
  unit <- if(reason=="included") list(id=id,time=time[ix],x=x[ix],step=step,
    time_label=time_label,value_label=value_label) else NULL
  list(unit=unit,audit=audit)
}

tarsr_seed <- function(id,base) {
  h <- as.double(base)
  for(v in utf8ToInt(id)) h <- (131*h+v) %% 2147483646
  as.integer(h+1)
}

tarsr_analyze <- function(unit,cfg) {
  RNGkind("Mersenne-Twister","Inversion","Rejection")
  set.seed(tarsr_seed(unit$id,cfg$seed))
  x <- unit$x; n <- length(x); tau <- cfg$tau; d <- length(tau)
  Ls <- as.integer(floor(cfg$bandwidth_c*n^(1/3)+1e-10))
  if(any(Ls<1L | Ls>=n)) stop("Invalid bandwidth for ",unit$id)
  main <- which(cfg$bandwidth_c==cfg$main_bandwidth_c); L <- Ls[main]
  q <- tarsr_fractional(x,tau,max(Ls)-1L)
  if(q$score_mean_error>1e-10 || min(eigen(q$D,symmetric=TRUE)$values)< -1e-10)
    stop("Fractional-score identity failed for ",unit$id)
  omega <- seq(0,pi,length.out=cfg$frequency_grid_size)
  diag_index <- seq_len(d)+(seq_len(d)-1L)*d
  rank_lags <- function(ties) {
    Z <- 1*outer(rank(x,ties.method=ties)/(n+1),tau,"<=")
    tarsr_lags(sweep(Z,2L,colMeans(Z),"-"),max(Ls)-1L)
  }
  mid <- rank_lags("average"); upper <- rank_lags("max")
  fits <- lapply(Ls,function(lb) list(
    Proposed=tarsr_window(q$G,lb,q$D),
    `No-correction`=tarsr_window(q$G,lb),
    `Average-rank`=tarsr_window(mid,lb),
    `Upper-rank`=tarsr_window(upper,lb)))
  raw_pool <- matrix(0,d*d*max(Ls),cfg$mc_draws)
  for(r in seq_len(cfg$mc_draws)) {
    U <- q$left[q$id]+stats::runif(n)*q$p[q$id]

    Y <- sweep(1*outer(U,tau,"<="),2L,tau,"-")
    raw_pool[,r] <- as.vector(tarsr_lags(Y,max(Ls)-1L))
  }
  sensitivity <- list(); primary_pool <- NULL
  for(b in seq_along(Ls)) {
    lb <- Ls[b]; est <- fits[[b]]
    pool <- raw_pool[seq_len(d*d*lb),,drop=FALSE]*
      rep(1-(0:(lb-1L))/lb,each=d*d)
    deviation <- pool-as.vector(est$Proposed)
    energy <- tarsr_pool_energy(deviation,d,lb)
    gain <- sum(q$D^2)/(2*pi)
    sensitivity[[b]] <- data.frame(c=cfg$bandwidth_c[b],L=lb,
      proposed_energy=tarsr_energy(est$Proposed),auxiliary_energy=mean(energy),
      auxiliary_mcse=tarsr_mcse(energy),correction_energy=gain,
      average_rank_distance=tarsr_energy(est[["Average-rank"]]-est$Proposed),
      upper_rank_distance=tarsr_energy(est[["Upper-rank"]]-est$Proposed))
    if(b==main) primary_pool <- pool
  }
  raw_pool <- NULL
  E <- fits[[main]]; P <- E$Proposed
  diff_pool <- primary_pool-as.vector(P)
  one_energy <- tarsr_pool_energy(diff_pool,d,L)
  quantile <- do.call(rbind,lapply(seq_len(d),function(j) {
    e <- tarsr_pool_energy(diff_pool,d,L,diag_index[j])
    ep <- tarsr_energy(P[diag_index[j],,drop=FALSE])
    cm <- matrix(E[["Average-rank"]][,1L],d,d)
    cu <- matrix(E[["Upper-rank"]][,1L],d,d)
    data.frame(tau=tau[j],correction_share=100*q$D[j,j]/q$K[j,j],
      proposed_energy=ep,auxiliary_energy=mean(e),auxiliary_mcse=tarsr_mcse(e),
      auxiliary_relative_pct=if(ep>0)100*mean(e)/ep else NA_real_,
      average_rank_mass_gap_pct=100*abs(cm[j,j]-q$K[j,j])/q$K[j,j],
      upper_rank_mass_gap_pct=100*abs(cu[j,j]-q$K[j,j])/q$K[j,j],
      boundary_distance=min(abs(cumsum(q$p)-tau[j])))
  }))
  averaging <- lapply(cfg$average_B,function(B) {
    ng <- cfg$mc_draws %/% B
    block <- vapply(seq_len(ng),function(g) {
      ids <- ((g-1L)*B+1L):(g*B)
      deviation <- rowMeans(primary_pool[,ids,drop=FALSE])-as.vector(P)
      tarsr_energy(matrix(deviation,d*d,L))
    },numeric(1))
    list(summary=data.frame(B=B,groups=ng,distance=mean(block),mcse=tarsr_mcse(block),
      one_over_B=mean(one_energy)/B),group_distances=block)
  })
  avg_table <- do.call(rbind,lapply(averaging,`[[`,"summary"))
  mean_C <- matrix(rowMeans(primary_pool),d*d,L)
  all_spectra <- lapply(E,tarsr_spectrum,omega=omega)
  all_spectra$Randomized <- tarsr_spectrum(matrix(primary_pool[,1L],d*d,L),omega)
  all_spectra$Randomized_mean <- tarsr_spectrum(mean_C,omega)
  cos_basis <- cbind(1,2*cos(outer(omega,seq_len(L-1L))))/(2*pi)
  bands <- lapply(seq_len(d),function(j) {
    rows <- diag_index[j]+(0:(L-1L))*d*d
    curves <- cos_basis%*%primary_pool[rows,seq_len(cfg$band_draws),drop=FALSE]
    list(lower=apply(curves,1L,stats::quantile,probs=.05,names=FALSE),
      upper=apply(curves,1L,stats::quantile,probs=.95,names=FALSE),
      curves=curves[,seq_len(min(6L,ncol(curves))),drop=FALSE])
  })
  normalize <- vapply(E,function(e)sqrt(sum((e[,1L]-as.vector(q$K))^2)),numeric(1))
  fp <- all_spectra$Proposed; fa <- all_spectra[["No-correction"]]

  constant_check <- max(Mod(fp-fa-as.vector(q$D)/(2*pi)))
  min_ev <- tarsr_psd_min(fp,d)
  if(normalize[["Proposed"]]>1e-10 || min_ev< -1e-9 || constant_check>1e-10)
    stop("Spectral structural check failed for ",unit$id)
  half <- n%/%2L
  first <- tabulate(q$id[seq_len(half)],length(q$p))/half
  second <- tabulate(q$id[(half+1L):n],length(q$p))/(n-half)
  stats <- data.frame(id=unit$id,n=n,n_unique=length(q$p),largest_atom=max(q$p),
    collision_probability=sum(q$p^2),half_distribution_TV=.5*sum(abs(first-second)),
    correction_share=100*sum(diag(q$D))/sum(diag(q$K)),
    correction_energy=sum(q$D^2)/(2*pi),auxiliary_energy=mean(one_energy),
    auxiliary_mcse=tarsr_mcse(one_energy),proposed_energy=tarsr_energy(P),
    proposed_normalization_error=normalize[["Proposed"]],
    average_rank_normalization_error=normalize[["Average-rank"]],
    upper_rank_normalization_error=normalize[["Upper-rank"]],
    minimum_eigenvalue=min_ev,L=L,stringsAsFactors=FALSE)
  list(unit=unit,summary=stats,quantile=quantile,omega=omega,values=q$values,p=q$p,
    K=q$K,D=q$D,coefficients=E,spectra=all_spectra,bands=bands,
    bandwidth=data.frame(c=cfg$bandwidth_c,L=Ls),
    bandwidth_spectra=lapply(fits,function(z)tarsr_spectrum(z$Proposed,omega)),
    sensitivity=do.call(rbind,sensitivity),averaging=avg_table,
    averaging_groups=lapply(averaging,`[[`,"group_distances"),
    single_draw_energies=one_energy,mean_randomized_coefficients=mean_C,
    checks=list(score_mean=q$score_mean_error,normalization=normalize,
      correction_constant=constant_check,
      mean_randomized_distance=tarsr_energy(mean_C-P)),
    random_seed=tarsr_seed(unit$id,cfg$seed))
}

tarsr_worker <- function(unit,cfg) {
  tryCatch(list(ok=TRUE,id=unit$id,result=tarsr_analyze(unit,cfg)),
    error=function(e)list(ok=FALSE,id=unit$id,error=conditionMessage(e)))
}

tarsr_save <- function(object,path) {
  dir.create(dirname(path),recursive=TRUE,showWarnings=FALSE)
  tmp <- paste0(path,".tmp")
  saveRDS(object,tmp,compress=FALSE)
  if(file.exists(path)) {
    backup <- paste0(path,".bak")
    if(file.exists(backup)) unlink(backup)
    if(!file.rename(path,backup)) stop("Cannot preserve previous results: ",path)
    if(!file.rename(tmp,path)) {
      file.rename(backup,path); stop("Cannot save updated results: ",path)
    }
    unlink(backup)
  } else if(!file.rename(tmp,path)) stop("Cannot save results: ",path)
  invisible(path)
}

tarsr_summary <- function(state) {
  results <- state$results
  qs <- do.call(rbind,lapply(results,function(z)cbind(id=z$unit$id,z$quantile)))
  ss <- do.call(rbind,lapply(results,`[[`,"summary"))
  vars <- c("correction_share","auxiliary_relative_pct",
            "average_rank_mass_gap_pct","upper_rank_mass_gap_pct")
  tab <- do.call(rbind,lapply(state$cfg$tau,function(tau) {
    z <- qs[abs(qs$tau-tau)<1e-12,,drop=FALSE]
    v <- vapply(vars,function(nm)stats::median(z[[nm]],na.rm=TRUE),numeric(1))
    data.frame(tau=tau,records=nrow(z),as.list(v),check.names=FALSE)
  }))
  list(series=ss,quantile=qs,table=tab,
    audit=state$audit,failures=state$failures)
}

tarsr_pick <- function(state) {
  requested <- state$cfg$display_id
  ids <- names(state$results)
  if(!is.null(requested) && nzchar(requested)) {
    if(!requested %in% ids) stop("display_id is not included: ",requested)
    return(requested)
  }
  ids[1L]
}

tarsr_colors <- function() c(Proposed="#0072B2",`No-correction`="#D55E00",
  `Average-rank`="#009E73",`Upper-rank`="#CC79A7",Randomized="#8A8A8A")

tarsr_device <- function(path,width,height,draw) {
  if(capabilities("cairo")) grDevices::cairo_pdf(path,width=width,height=height,
    family="sans",pointsize=10) else
    grDevices::pdf(path,width=width,height=height,family="Helvetica",pointsize=10)
  on.exit(grDevices::dev.off(),add=TRUE)
  draw()
  invisible(path)
}

tarsr_axis <- function() {
  graphics::axis(1,at=c(0,.25,.5,.75,1),
    labels=expression(0,pi/4,pi/2,3*pi/4,pi))
}

tarsr_main_plot <- function(state,path) {
  id <- tarsr_pick(state); z <- state$results[[id]]; cfg <- state$cfg
  col <- tarsr_colors(); tau <- cfg$tau; d <- length(tau)
  jj <- seq_len(d)+(seq_len(d)-1L)*d
  selected <- unique(c(1L,which.min(abs(tau-.5)),d))
  if(length(selected)<3L) selected <- c(selected,selected[1L])
  tarsr_device(path,11.5,7.3,function() {
    graphics::layout(matrix(c(1,2,3,4,5,6,7,7,7),3,3,byrow=TRUE),heights=c(1,1,.19))
    graphics::par(mar=c(3.7,4.0,2.5,1.0),oma=c(.2,0,2.0,0),
      mgp=c(2.4,.75,0),tcl=-.25,las=1,cex=.9)
    elapsed <- (z$unit$time-z$unit$time[1L])/z$unit$step
    graphics::plot(elapsed,z$unit$x,type="s",col=col[["Proposed"]],lwd=1.0,
      xlab=z$unit$time_label,ylab=z$unit$value_label,main="(a) Recorded series")
    graphics::barplot(z$p,names.arg=format(z$values,trim=TRUE),col="#94B8CE",
      border=NA,space=.2,xlab=z$unit$value_label,ylab="Relative frequency",
      main="(b) Observed probability masses",cex.names=.8)
    av <- z$averaging; base <- av$distance[av$B==1L]
    if(is.finite(base) && base>1e-25) {
      y <- av$distance/base; se <- av$mcse/base
      graphics::plot(av$B,y,log="xy",type="n",xaxt="n",
        ylim=range(c(pmax(y-se,1e-6),y+se,1/av$B)),
        xlab="Number of randomized spectra, B",ylab="Relative squared distance",
        main="(c) Conditional averaging")
      graphics::axis(1,at=av$B,labels=av$B)
      graphics::lines(av$B,1/av$B,col="gray35",lty=2,lwd=1.4)
      graphics::segments(av$B,pmax(y-se,1e-6),av$B,y+se,col=col[["Proposed"]])
      graphics::lines(av$B,y,type="b",pch=16,col=col[["Proposed"]],lwd=1.4)
      graphics::legend("topright",c("Conditional MC mean","1/B reference"),
        col=c(col[["Proposed"]],"gray35"),lty=c(1,2),pch=c(16,NA),bty="n",cex=.8)
    } else {
      graphics::plot.new(); graphics::title("(c) Conditional averaging")
      graphics::text(.5,.5,"No auxiliary variation at this quantile grid",cex=.8)
    }
    for(k in seq_len(3L)) {
      j <- selected[k]; idx <- jj[j]; band <- z$bands[[j]]
      values <- c(band$upper,Re(z$spectra$Proposed[idx,]),
        Re(z$spectra[["Average-rank"]][idx,]),Re(z$spectra[["Upper-rank"]][idx,]))
      yr <- c(0,max(values,na.rm=TRUE)*1.05)
      if(yr[2L]<=0) yr[2L] <- 1
      xx <- z$omega/pi
      graphics::plot(xx,Re(z$spectra$Proposed[idx,]),type="n",xaxt="n",ylim=yr,
        xlab=expression(omega),ylab="Spectral density",
        main=paste0("(",letters[3L+k],") Quantile ",format(tau[j],nsmall=2)))
      tarsr_axis()
      graphics::polygon(c(xx,rev(xx)),c(band$lower,rev(band$upper)),
        col=grDevices::adjustcolor("gray60",alpha.f=.23),border=NA)
      graphics::lines(xx,Re(z$spectra$Randomized[idx,]),col="gray65",lwd=.6)
      for(method in c("Average-rank","Upper-rank","No-correction","Proposed"))
        graphics::lines(xx,Re(z$spectra[[method]][idx,]),col=col[[method]],
          lwd=if(method=="Proposed")1.8 else 1.1,
          lty=switch(method,"Average-rank"=3,"Upper-rank"=4,"No-correction"=2,1))
    }
    graphics::mtext(paste(cfg$title," | ",id," | n = ",z$summary$n,
      ", L = ",z$summary$L,sep=""),side=3,outer=TRUE,line=.5,font=2,cex=1.0)
    graphics::par(mar=c(0,0,0,0))
    graphics::plot.new()
    graphics::legend(.5,.72,names(col),col=col,lty=c(1,2,3,4,1),
      lwd=c(1.8,1.1,1.1,1.1,.6),horiz=TRUE,bty="n",cex=.9,xjust=.5,yjust=.5)
    graphics::text(.5,.20,
      "Shading: conditional 5%-95% randomization range, not a confidence interval. Bars in (c): one MC standard error.",
      cex=.75)
  })
}

tarsr_summary_plot <- function(state,path) {
  S <- state$summary$series; Q <- state$summary$quantile
  z <- state$results[[tarsr_pick(state)]]; cfg <- state$cfg
  tarsr_device(path,9.5,7.0,function() {
    graphics::par(mfrow=c(2,2),mar=c(4.0,4.4,2.6,1.2),oma=c(0,0,2,0),
      mgp=c(2.7,.8,0),tcl=-.25,las=1,cex=.9)
    graphics::plot(S$n,S$correction_share,pch=21,bg="#0072B2",col="white",cex=1.2,
      ylim=c(0,100),xlab="Number of consecutive observations",
      ylab="Zero-lag correction share (%)",main="(a) Included series")
    aux <- 100*S$auxiliary_energy/S$proposed_energy
    graphics::plot(S$collision_probability,aux,pch=21,bg="#D55E00",col="white",cex=1.2,
      xlab=expression(sum(hat(p)[k]^2)),ylab="Relative auxiliary energy (%)",
      main="(b) Conditional randomization variation")
    groups <- lapply(cfg$tau,function(t)Q$correction_share[abs(Q$tau-t)<1e-12])
    names(groups) <- format(cfg$tau,nsmall=2)
    graphics::boxplot(groups,col="#BAD3E2",border="#3F647A",outline=TRUE,
      ylim=c(0,100),xlab=expression(tau),ylab="Zero-lag correction share (%)",
      main="(c) Distribution across included series")
    j <- which.min(abs(cfg$tau-.5)); d <- length(cfg$tau); idx <- j+(j-1L)*d
    curves <- lapply(z$bandwidth_spectra,function(f)Re(f[idx,]))
    yr <- c(0,max(unlist(curves))*1.05); if(yr[2L]<=0)yr[2L] <- 1
    cols <- grDevices::hcl.colors(length(curves),"Dark 3")
    graphics::plot(z$omega/pi,curves[[1L]],type="n",xaxt="n",ylim=yr,
      xlab=expression(omega),ylab="Spectral density",
      main=paste0("(d) Bandwidth sensitivity, tau = ",cfg$tau[j]))
    tarsr_axis()
    for(k in seq_along(curves)) graphics::lines(z$omega/pi,curves[[k]],col=cols[k],
      lwd=1.6,lty=k)
    graphics::legend("topright",paste0("c = ",cfg$bandwidth_c),col=cols,
      lwd=1.6,lty=seq_along(curves),bty="n",cex=.85)
    graphics::mtext(paste0(cfg$title," | ",nrow(S)," included series"),
      side=3,outer=TRUE,line=.4,font=2)
  })
}

tarsr_table <- function(state,folder) {
  tab <- state$summary$table; name <- paste0("table_",state$cfg$prefix,"_summary")
  utils::write.csv(tab,file.path(folder,paste0(name,".csv")),row.names=FALSE)
  rows <- apply(tab,1L,function(r) paste0(paste(c(sprintf("%.2f",as.numeric(r[1L])),
    sprintf("%.1f",as.numeric(r[c("correction_share","auxiliary_relative_pct",
      "average_rank_mass_gap_pct","upper_rank_mass_gap_pct")]))),collapse=" & ")," \\\\"))
  caption <- paste0("Median diagnostics across ",length(state$results),
    " included ",state$cfg$series_description,". Correction is $100\\widehat D_{jj}/K_{jj}$. ",
    "Auxiliary energy is the conditional mean integrated squared distance of a single randomized ",
    "estimate from Proposed, divided by the integrated squared Proposed estimate and expressed as a percentage. ",
    "Mass gaps are absolute deviations of integrated diagonal spectra from $K_{jj}$, as percentages of $K_{jj}$. ",
    "All estimators use $L=\\lfloor ",state$cfg$main_bandwidth_c,"n^{1/3}\\rfloor$.")
  lines <- c("\\begin{table}[t]","\\centering","\\small",paste0("\\caption{",caption,"}"),
    paste0("\\label{tab:",state$cfg$prefix,"-summary}"),"\\begin{tabular}{rrrrr}",
    "\\hline","$\\tau$ & Correction (\\%) & Auxiliary (\\%) & Average-rank gap (\\%) & Upper-rank gap (\\%) \\\\",
    "\\hline",rows,"\\hline","\\end{tabular}","\\end{table}")
  writeLines(lines,file.path(folder,paste0(name,".tex")))
}

tarsr_export <- function(state) {
  out <- state$cfg$output_dir
  fig <- file.path(out,"frame"); tbl <- file.path(out,"tables")
  dir.create(fig,recursive=TRUE,showWarnings=FALSE)
  dir.create(tbl,recursive=TRUE,showWarnings=FALSE)
  tarsr_table(state,tbl)
  tarsr_main_plot(state,file.path(fig,paste0("figure_",state$cfg$prefix,"_main.pdf")))
  tarsr_summary_plot(state,file.path(fig,paste0("figure_",state$cfg$prefix,"_summary.pdf")))
  invisible(state)
}

tarsr_run <- function(prepared,cfg) {
  cfg <- tarsr_validate(cfg)
  if(!length(prepared$units)) stop("No record meets the length and variation rules.")
  units <- prepared$units
  if(anyDuplicated(vapply(units,`[[`,character(1),"id"))) stop("Duplicate series IDs")
  names(units) <- vapply(units,`[[`,character(1),"id")
  dir.create(cfg$output_dir,recursive=TRUE,showWarnings=FALSE)
  path <- file.path(cfg$output_dir,paste0("TARS_",cfg$prefix,"_results.rds"))
  key_cfg <- cfg
  key_cfg[c("workers","resume","output_dir","cache_dir","display_id",
            "allow_download")] <- NULL
  signature <- list(version=tarsr_version(),configuration=key_cfg,
    data=lapply(units,function(z)z[c("id","time","x","step")]))
  state <- if(cfg$resume && file.exists(path)) readRDS(path) else NULL
  if(!is.null(state) && !identical(state$signature,signature))
    stop("Configuration or input data changed. Use a new output_dir or set resume=FALSE.")
  if(is.null(state)) state <- list(version=tarsr_version(),status="running",
    signature=signature,cfg=cfg,source=prepared$source,audit=prepared$audit,
    raw_data=prepared$raw_data,results=list(),failures=list(),
    created_utc=format(Sys.time(),tz="UTC",usetz=TRUE),
    definitions=list(
      target="Distributional-transform spectrum of the observed recorded process",
      omega="Angular frequency in radians per sampling interval, plotted over [0, pi]",
      integration="All squared distances use Parseval over [-pi, pi]",
      randomization="Independent uniforms across time, shared across quantile levels; no subsequent ranking",
      rng="Mersenne-Twister with Inversion and Rejection, with deterministic record-specific seeds",
      bands="Pointwise 5th-95th percentiles over auxiliary randomizers conditional on the observed record; not confidence intervals",
      averaging="Disjoint groups of B independent randomized spectra; one MC standard error is displayed",
      correction="Dhat/(2*pi); its integrated squared norm is the exact unweighted ISE improvement over No-correction under the stated target",
      auxiliary="Conditional randomization contribution to squared-error risk; no empirical true-spectrum MSE is computed",
      ranks="Average/max rank divided by n+1; their indicator scores are centered by their own sample means",
      selection="Longest contiguous valid run per predefined unit; earliest run in a length tie; constant and short runs excluded",
      stationarity="Within-record stationarity is a modeling assumption; half-distribution TV is descriptive only"))
  state$cfg <- cfg; state$source <- prepared$source; state$audit <- prepared$audit
  state$raw_data <- prepared$raw_data
  state$status <- "running"; state$failures <- list()
  pending <- setdiff(names(units),names(state$results))
  message(length(units)," included series; ",length(pending)," remaining.")
  oldkind <- RNGkind(); had <- exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE)
  if(had) oldseed <- get(".Random.seed",envir=.GlobalEnv)
  on.exit({do.call(RNGkind,as.list(oldkind)); if(had)assign(".Random.seed",oldseed,envir=.GlobalEnv)
    else if(exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE))rm(".Random.seed",envir=.GlobalEnv)},add=TRUE)
  cl <- NULL
  if(length(pending) && cfg$workers>1L) {
    cl <- parallel::makePSOCKcluster(min(cfg$workers,length(pending)))
    on.exit(parallel::stopCluster(cl),add=TRUE)
    env <- environment(tarsr_run)
    exports <- ls(envir=env,all.names=TRUE,pattern="^tarsr_")
    parallel::clusterExport(cl,exports,envir=env)
  }
  if(length(pending)) {
    batches <- split(pending,ceiling(seq_along(pending)/max(1L,cfg$workers)))
    for(ids in batches) {
      chunk <- if(is.null(cl)) lapply(units[ids],tarsr_worker,cfg=cfg) else
        parallel::parLapplyLB(cl,units[ids],tarsr_worker,cfg=cfg)
      for(z in chunk) {
        if(z$ok) state$results[[z$id]] <- z$result else state$failures[[z$id]] <- z$error
      }
      tarsr_save(state,path)
      message("Completed ",length(state$results)," / ",length(units)," series.")
      if(length(state$failures)) stop("Analysis failed for ",paste(names(state$failures),collapse=", "),
        ". Details and completed results are in ",path)
    }
  }
  state$results <- state$results[names(units)]
  state$summary <- tarsr_summary(state)
  state$display_id <- tarsr_pick(state)
  state$session_info <- utils::sessionInfo()
  state$status <- "analysis_complete"
  tarsr_save(state,path)
  tarsr_export(state)
  state$status <- "complete"
  tarsr_save(state,path)
  message("Saved: ",normalizePath(path,winslash="/"))
  invisible(state)
}

tars_spo2_data_file <- function(name,url,cfg) {
  destination <- file.path(cfg$cache_dir,name)
  if(file.exists(destination) && !dir.exists(destination) &&
     file.info(destination)$size>0) return(destination)
  if(isTRUE(cfg$allow_download)) return(tarsr_download(url,destination))
  stop("Missing offline data file: ",destination,
       "\nExtract the complete TARS_SpO2_offline.zip, keeping its data folder.",
       "\nThen run source(file.choose()) and select the extracted TARS_SpO2.R.",
       "\nFor an existing data folder, set SPO2_CFG$cache_dir to its full path.",
       call.=FALSE)
}

tars_spo2_prepare <- function(cfg) {
  stopifnot(length(cfg$records)>0L,!anyDuplicated(cfg$records),
    all(cfg$records %in% 1:53),length(cfg$valid_range)==2L,
    all(is.finite(cfg$valid_range)),cfg$valid_range[1L]<cfg$valid_range[2L],
    is.null(cfg$allow_download) || (is.logical(cfg$allow_download) &&
      length(cfg$allow_download)==1L && !is.na(cfg$allow_download)))
  units <- audits <- raw <- list()
  sources <- list()
  for(i in sort(cfg$records)) {
    id <- sprintf("BIDMC_%02d",i); name <- sprintf("bidmc_%02d_Numerics.csv",i)
    url <- paste0("https://physionet.org/files/bidmc/1.0.0/bidmc_csv/",name)
    file <- tars_spo2_data_file(name,url,cfg)
    dat <- utils::read.csv(file,check.names=FALSE,strip.white=TRUE,
      na.strings=c("NA","NaN","nan","","NULL"))
    names(dat) <- trimws(names(dat))
    tc <- which(tolower(names(dat))=="time [s]")
    xc <- which(tolower(gsub("[^a-zA-Z0-9]","",names(dat)))=="spo2")
    if(length(tc)!=1L || length(xc)!=1L) stop("Unexpected BIDMC columns in ",file)
    time <- suppressWarnings(as.numeric(dat[[tc]]))
    original <- suppressWarnings(as.numeric(dat[[xc]]))
    if(any(!is.finite(time)) || any(abs(time-round(time))>1e-8) || anyDuplicated(time))
      stop("Invalid, fractional, or duplicate BIDMC timestamps in ",file)
    o <- order(time); time <- time[o]; original <- original[o]
    grid <- seq(min(time),max(time),by=1)
    value <- original[match(grid,time)]
    invalid <- is.finite(value) & (value<cfg$valid_range[1L] | value>cfg$valid_range[2L])
    clean <- value; clean[invalid] <- NA_real_
    z <- tarsr_unit(id,grid,clean,1,cfg$min_n,"Elapsed time (seconds)","Recorded SpO2 (%)")
    z$audit$out_of_range_count <- sum(invalid)
    z$audit$missing_timestamp_count <- sum(!grid %in% time)
    z$audit$noninteger_values <- sum(is.finite(clean) & abs(clean-round(clean))>1e-8)
    z$audit$record <- i
    if(!is.null(z$unit)) units[[id]] <- z$unit
    audits[[id]] <- z$audit
    raw[[id]] <- data.frame(time_seconds=grid,SpO2_original=value,SpO2=clean)
    sources[[id]] <- data.frame(id=id,url=url,file=normalizePath(file,winslash="/"),
      md5=unname(tools::md5sum(file)),stringsAsFactors=FALSE)
    if(i %% 10L==0L || i==max(cfg$records)) message("Read BIDMC record ",i,".")
  }
  audit <- do.call(rbind,audits); rownames(audit) <- NULL
  message("BIDMC: ",sum(audit$included)," / ",nrow(audit)," records included.")
  list(units=units,audit=audit,raw_data=raw,
    source=list(provider="BIDMC PPG and Respiration Dataset, PhysioNet, version 1.0.0",
      source_page="https://physionet.org/content/bidmc/1.0.0/",
      dataset_doi="10.13026/C2208R",files=do.call(rbind,sources),
      original_publication_doi="10.1109/TBME.2016.2613124",
      license="Open Data Commons Attribution License v1.0",
      processing="Longest uninterrupted 1-Hz valid SpO2 run per recording; values outside valid_range are missing; no rounding, interpolation, or concatenation",
      stationarity="Within-record stationarity is assumed for the spectral interpretation; the observed monitor process is the estimand"))
}

tars_spo2_run <- function(cfg=SPO2_CFG) {
  cfg <- tarsr_validate(cfg)
  prepared <- tars_spo2_prepare(cfg)
  tarsr_run(prepared,cfg)
}

if(isTRUE(getOption("TARS.real.autorun",TRUE))) {
  TARS_SPO2_RESULT <- tars_spo2_run(SPO2_CFG)
}
