CFG <- list(
  n_rep = 500L,
  workers = 8L,
  n = c(256L, 512L, 1024L),
  tau = c(0.10, 0.25, 0.50, 0.75, 0.90),
  bandwidth_c = c(0.5, 1, 2),
  main_bandwidth_c = 2,
  models = c("IID", "Binary", "Cyclic", "Gaussian3", "Gaussian5", "Gaussian9"),
  mechanism_n = 512L,
  mechanism_rep = 200L,
  randomization_B = c(1L, 2L, 5L, 10L, 20L, 50L),
  frequency_grid_size = 129L,
  structure_grid_size = 17L,
  curve_n = 512L,
  seed = 20261007L,
  truth_tolerance = 1e-10,
  truth_max_lag = 512L,
  checkpoint_every = 48L,
  resume = TRUE,
  output_dir = "TARS_point_output"
)

tars_engine <- function() "TARS-point-2.0"

tars_validate <- function(cfg) {
  whole <- function(x) length(x)>0L && all(is.finite(x)) && all(x==as.integer(x))
  stopifnot(is.list(cfg), whole(cfg$n_rep), length(cfg$n_rep)==1L, cfg$n_rep>=2L,
    whole(cfg$mechanism_rep), length(cfg$mechanism_rep)==1L, cfg$mechanism_rep>=2L,
    whole(cfg$workers), length(cfg$workers)==1L, cfg$workers>=1L,
    whole(cfg$n), all(cfg$n>=32L), !anyDuplicated(cfg$n),
    length(cfg$tau)>=2L, all(is.finite(cfg$tau)), all(diff(cfg$tau)>0),
    all(cfg$tau>0 & cfg$tau<1), length(cfg$bandwidth_c)>0L,
    all(is.finite(cfg$bandwidth_c)), all(cfg$bandwidth_c>0),
    !anyDuplicated(cfg$bandwidth_c), length(cfg$main_bandwidth_c)==1L,
    cfg$main_bandwidth_c %in% cfg$bandwidth_c,
    length(cfg$models)>0L, !anyDuplicated(cfg$models),
    all(cfg$models %in% names(tars_models())),
    length(cfg$mechanism_n)==1L, cfg$mechanism_n %in% cfg$n,
    length(cfg$curve_n)==1L, cfg$curve_n %in% cfg$n,
    whole(cfg$randomization_B), all(cfg$randomization_B>=1L),
    1L %in% cfg$randomization_B, max(cfg$randomization_B)>=2L,
    whole(cfg$frequency_grid_size), length(cfg$frequency_grid_size)==1L,
    cfg$frequency_grid_size>=17L,
    whole(cfg$structure_grid_size), length(cfg$structure_grid_size)==1L,
    cfg$structure_grid_size>=3L, cfg$structure_grid_size<=cfg$frequency_grid_size,
    whole(cfg$seed), length(cfg$seed)==1L,
    cfg$truth_tolerance>0, cfg$truth_tolerance<1e-3,
    whole(cfg$truth_max_lag), cfg$truth_max_lag>=1L,
    whole(cfg$checkpoint_every), length(cfg$checkpoint_every)==1L,
    cfg$checkpoint_every>=1L, is.logical(cfg$resume), length(cfg$resume)==1L,
    is.character(cfg$output_dir), length(cfg$output_dir)==1L, nzchar(cfg$output_dir))
  cfg$n <- sort(as.integer(cfg$n))
  cfg$bandwidth_c <- sort(cfg$bandwidth_c)
  cfg$randomization_B <- sort(unique(as.integer(cfg$randomization_B)))
  for (nm in c("n_rep","mechanism_rep","workers","checkpoint_every")) cfg[[nm]]<-as.integer(cfg[[nm]])
  for (n in cfg$n) {
    L <- floor(cfg$bandwidth_c*n^(1/3)+1e-10)
    if (any(L<1L | L>=n)) stop("Bandwidths must satisfy 1 <= L < n.")
  }
  cfg
}

tars_signature <- function(cfg) {
  cfg[c("n_rep","mechanism_rep","workers","checkpoint_every","resume","output_dir")]<-NULL
  list(engine=tars_engine(),design=cfg,models=tars_models()[cfg$models])
}

tars_prepare <- function(cfg) {
  omega<-seq(0,pi,length.out=cfg$frequency_grid_size)
  max_L<-max(floor(outer(cfg$bandwidth_c,cfg$n^(1/3))+1e-10))
  truth<-lapply(tars_models()[cfg$models],function(m) {
    message("Preparing population target: ",m$id)
    tars_truth(m,cfg,omega,as.integer(max_L-1L))
  })
  d<-length(cfg$tau)
  jj<-(seq_len(d)-1L)*d+seq_len(d)
  pairs<-unique(rbind(c(1L,d),c(which.min(abs(cfg$tau-.25)),which.min(abs(cfg$tau-.75)))))
  pairs<-pairs[pairs[,1L]!=pairs[,2L],,drop=FALSE]
  components<-data.frame(j=seq_len(d),k=seq_len(d),part="real")
  if(nrow(pairs)) for(i in seq_len(nrow(pairs))) components<-rbind(components,
    data.frame(j=pairs[i,1L],k=pairs[i,2L],part=c("real","imag")))
  components$tau_j<-cfg$tau[components$j]
  components$tau_k<-cfg$tau[components$k]
  components$index<-components$j+(components$k-1L)*d
  list(cfg=cfg,truth=truth,omega=omega,d=d,K=tars_K(cfg$tau),diag_index=jj,
    offdiag_index=setdiff(seq_len(d*d),jj),components=components,
    structure_index=unique(round(seq(1,length(omega),length.out=cfg$structure_grid_size))),
    methods=c("Proposed","Randomized","Average-rank","Upper-rank","No-correction","Oracle"))
}

tars_fractional <- function(x, s, tau, max_lag) {
  phat<-tabulate(x,nbins=s)/length(x)
  a<-tars_scores(phat,tau)
  Z<-sweep(a[x,,drop=FALSE],2L,tau,"-")
  G<-tars_lags(Z,max_lag)
  D<-tars_K(tau)-matrix(G[,1L],length(tau))
  list(G=G,D=D,phat=phat,score_mean_error=max(abs(colMeans(Z))))
}

tars_randomized_lags <- function(x,phat,tau,max_lag) {
  U<-(cumsum(phat)-phat)[x]+runif(length(x))*phat[x]

  Y<-sweep(outer(U,tau,"<="),2L,tau,"-")
  tars_lags(Y,max_lag)
}

tars_estimation_lags <- function(x,truth,tau,max_lag) {
  q<-tars_fractional(x,length(truth$model$p),tau,max_lag)
  rank_scores<-function(ties) {
    z<-outer(rank(x,ties.method=ties)/(length(x)+1),tau,"<=")*1
    sweep(z,2L,colMeans(z),"-")
  }
  list(Proposed=q$G,Randomized=tars_randomized_lags(x,q$phat,tau,max_lag),
    `Average-rank`=tars_lags(rank_scores("average"),max_lag),
    `Upper-rank`=tars_lags(rank_scores("max"),max_lag),`No-correction`=q$G,
    Oracle=tars_lags(truth$A[x,,drop=FALSE],max_lag),
    Dhat=q$D,score_mean_error=q$score_mean_error)
}

tars_coefficients <- function(raw,L,truth) {
  list(Proposed=tars_window(raw$Proposed,L,raw$Dhat),
    Randomized=tars_window(raw$Randomized,L),
    `Average-rank`=tars_window(raw[["Average-rank"]],L),
    `Upper-rank`=tars_window(raw[["Upper-rank"]],L),
    `No-correction`=tars_window(raw[["No-correction"]],L),
    Oracle=tars_window(raw$Oracle,L,truth$D))
}

tars_primary <- function(x,cfg) abs(x-cfg$main_bandwidth_c)<1e-12

tars_main_job <- function(job,ctx) {
  cfg<-ctx$cfg;n<-job$n;truth<-ctx$truth[[job$model]]
  x<-tars_sample(truth$model,n)
  Ls<-as.integer(floor(cfg$bandwidth_c*n^(1/3)+1e-10))
  raw<-tars_estimation_lags(x,truth,cfg$tau,max(Ls)-1L)
  emin<-min(eigen(raw$Dhat,symmetric=TRUE,only.values=TRUE)$values)
  if(raw$score_mean_error>1e-10 || emin< -1e-10) stop("Invalid fractional scores or correction matrix.")
  metrics<-risk<-correction<-list();curves<-coefficients<-NULL;k<-0L
  target_energy<-unname(tars_error(truth$targetG,truth$targetG*0,ctx)["ISE"])
  for(b in seq_along(Ls)) {
    L<-Ls[b];E<-tars_coefficients(raw,L,truth)
    central<-tars_primary(cfg$bandwidth_c[b],cfg)
    err<-lapply(E,tars_error,target=truth$targetG,ctx=ctx)
    if(any(!is.finite(unlist(err)))) stop("Non-finite estimation error.")
    for(method in ctx$methods) {
      k<-k+1L
      Fi<-if(central) tars_spectrum(E[[method]],ctx$omega[ctx$structure_index]) else NULL
      metrics[[k]]<-data.frame(c=cfg$bandwidth_c[b],L=L,method=method,as.list(err[[method]]),
        relative_ISE=unname(err[[method]]["ISE"])/target_energy,
        normalization_error=sqrt(sum((E[[method]][,1L]-as.vector(ctx$K))^2)),
        min_eigenvalue=if(central) tars_min_eigen(Fi,ctx$d) else NA_real_,check.names=FALSE)
      if(central && n==cfg$curve_n) {
        F<-tars_spectrum(E[[method]],ctx$omega)
        curves[[method]]<-tars_component(F,ctx$components,seq_along(ctx$omega))
      }
    }
    if(central) coefficients<-E
    aux<-unname(tars_error(E$Randomized,E$Proposed,ctx)["ISE"])
    gain<-unname(err$Randomized["ISE"]-err$Proposed["ISE"])
    risk[[b]]<-data.frame(c=cfg$bandwidth_c[b],L=L,paired_gain=gain,
      auxiliary_energy=aux,decomposition_residual=gain-aux)
    removed<-unname(err[["No-correction"]]["ISE"]-err$Proposed["ISE"])
    energy<-sum(raw$Dhat^2)/(2*pi)
    correction[[b]]<-data.frame(c=cfg$bandwidth_c[b],L=L,
      proposed_ISE=unname(err$Proposed["ISE"]),uncorrected_ISE=unname(err[["No-correction"]]["ISE"]),
      removed_error=removed,correction_energy=energy,identity_residual=removed-energy,
      correction_matrix_error=sum((raw$Dhat-truth$D)^2),population_omission_floor=sum(truth$D^2)/(2*pi))
  }
  meta<-data.frame(model=job$model,n=n,replication=job$replication)
  attach<-function(z)cbind(meta,do.call(rbind,z),row.names=NULL)
  list(kind="main",metrics=attach(metrics),risk=attach(risk),correction=attach(correction),
    curves=curves,coefficients=coefficients,
    checks=c(score_mean_error=raw$score_mean_error,correction_min_eigenvalue=emin))
}

tars_mechanism_job <- function(job,ctx) {
  cfg<-ctx$cfg;truth<-ctx$truth[[job$model]];n<-job$n
  x<-tars_sample(truth$model,n)
  L<-as.integer(floor(cfg$main_bandwidth_c*n^(1/3)+1e-10))
  q<-tars_fractional(x,length(truth$model$p),cfg$tau,L-1L)
  P<-tars_window(q$G,L,q$D)
  iseP<-unname(tars_error(P,truth$targetG,ctx)["ISE"])
  S<-P*0;single_energy<-0;rows<-list()
  for(b in seq_len(max(cfg$randomization_B))) {
    E<-tars_window(tars_randomized_lags(x,q$phat,cfg$tau,L-1L),L)

    S<-S+E
    single_energy<-single_energy+unname(tars_error(E,P,ctx)["ISE"])
    if(b %in% cfg$randomization_B) {
      avg<-S/b;loss<-unname(tars_error(avg,truth$targetG,ctx)["ISE"])
      energy<-unname(tars_error(avg,P,ctx)["ISE"])
      rows[[length(rows)+1L]]<-data.frame(B=b,proposed_ISE=iseP,averaged_ISE=loss,
        excess_loss=loss-iseP,auxiliary_energy=energy,identity_residual=loss-iseP-energy)
    }
  }
  z<-do.call(rbind,rows)
  z$single_draw_energy_reference<-single_energy/max(cfg$randomization_B)
  z$one_over_B_reference<-z$single_draw_energy_reference/z$B
  z$scaling_residual<-z$auxiliary_energy-z$one_over_B_reference
  list(kind="mechanism",averaging=cbind(data.frame(model=job$model,n=n,
    replication=job$replication,c=cfg$main_bandwidth_c,L=L),z,row.names=NULL))
}

tars_job <- function(job,ctx) {
  if(job$kind=="main") tars_main_job(job,ctx) else tars_mechanism_job(job,ctx)
}

tars_jobs <- function(cfg) {
  oldkind<-RNGkind();had<-exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE)
  if(had) oldseed<-get(".Random.seed",envir=.GlobalEnv)
  on.exit({do.call(RNGkind,as.list(oldkind));if(had) assign(".Random.seed",oldseed,envir=.GlobalEnv)
    else if(exists(".Random.seed",envir=.GlobalEnv,inherits=FALSE)) rm(".Random.seed",envir=.GlobalEnv)},add=TRUE)
  RNGkind("L'Ecuyer-CMRG","Inversion","Rejection");set.seed(cfg$seed)
  rng<-get(".Random.seed",envir=.GlobalEnv);jobs<-list()

  for(r in seq_len(max(cfg$n_rep,cfg$mechanism_rep))) for(n in cfg$n) for(model in cfg$models) {
    if(r<=cfg$n_rep) {
      id<-paste("main",model,n,r,sep="_")
      jobs[[id]]<-list(id=id,kind="main",model=model,n=n,replication=r,rng=rng)
    }
    if(n==cfg$mechanism_n && r<=cfg$mechanism_rep) {
      id<-paste("mechanism",model,n,r,sep="_")
      jobs[[id]]<-list(id=id,kind="mechanism",model=model,n=n,replication=r,
        rng=parallel::nextRNGSubStream(rng))
    }
    rng<-parallel::nextRNGStream(rng)
  }
  jobs
}

tars_accumulate <- function(state,result,job) {
  if(!is.null(result$curves)) {
    z<-state$curves[[job$model]]
    if(is.null(z)) z<-list(count=0L,sum=lapply(result$curves,function(m)m*0),sumsq=lapply(result$curves,function(m)m*0))
    z$count<-z$count+1L
    for(m in names(result$curves)) {
      z$sum[[m]]<-z$sum[[m]]+result$curves[[m]]
      z$sumsq[[m]]<-z$sumsq[[m]]+result$curves[[m]]^2
    }
    state$curves[[job$model]]<-z
  }
  if(!is.null(result$coefficients)) {
    key<-paste(job$model,job$n,sep="_");z<-state$coefficient_sums[[key]]
    if(is.null(z)) z<-list(model=job$model,n=job$n,count=0L,sum=lapply(result$coefficients,function(m)m*0))
    z$count<-z$count+1L
    for(m in names(result$coefficients)) z$sum[[m]]<-z$sum[[m]]+result$coefficients[[m]]
    state$coefficient_sums[[key]]<-z
  }
  state
}

tars_summary_fields <- function(z,vars) {
  out<-list(completed=nrow(z))
  for(v in vars) {
    out[[paste0(v,"_mean")]]<-tars_mean(z[[v]])
    out[[paste0(v,"_mcse")]]<-tars_mcse(z[[v]])
  }
  out
}

tars_summarize <- function(state) {
  cfg<-state$config;ctx<-state$context;M<-tars_bind_records(state,"metrics")
  vars<-c("ISE","relative_ISE","diagonal","real_cross","imag_cross",paste0("D",seq_along(cfg$tau)))
  accuracy<-tars_group(M,c("model","n","c","L","method"),function(z)tars_summary_fields(z,vars))
  p<-M[M$method=="Proposed",c("model","n","replication","c","L","ISE")]
  paired<-do.call(rbind,lapply(setdiff(ctx$methods,"Proposed"),function(m) {
    q<-M[M$method==m,c("model","n","replication","c","L","ISE")]
    zz<-merge(p,q,by=c("model","n","replication","c","L"),suffixes=c("_p","_other"))
    ans<-tars_group(zz,c("model","n","c","L"),function(z) {
      g<-z$ISE_other-z$ISE_p
      list(completed=nrow(z),proposed_MISE=mean(z$ISE_p),comparator_MISE=mean(z$ISE_other),
        paired_gain=mean(g),paired_gain_mcse=tars_mcse(g),
        relative_reduction=1-mean(z$ISE_p)/mean(z$ISE_other),fraction_proposed_lower=mean(g>0))
    });ans$comparator<-m;ans
  }))
  risk<-tars_group(tars_bind_records(state,"risk"),c("model","n","c","L"),function(z)
    tars_summary_fields(z,c("paired_gain","auxiliary_energy","decomposition_residual")))
  correction<-tars_group(tars_bind_records(state,"correction"),c("model","n","c","L"),function(z) {
    ans<-tars_summary_fields(z,c("proposed_ISE","uncorrected_ISE","removed_error","correction_energy","correction_matrix_error"))
    ans$max_identity_residual<-max(abs(z$identity_residual))
    ans$population_omission_floor<-z$population_omission_floor[1L];ans
  })
  central<-M[tars_primary(M$c,cfg),,drop=FALSE]
  structure<-tars_group(central,c("model","n","method"),function(z)list(completed=nrow(z),
    mean_normalization_error=mean(z$normalization_error),max_normalization_error=max(z$normalization_error),
    smallest_eigenvalue=min(z$min_eigenvalue),fraction_negative_beyond_roundoff=mean(z$min_eigenvalue< -1e-10)))
  averaging<-tars_group(tars_bind_records(state,"averaging"),c("model","n","c","L","B"),function(z) {
    ans<-tars_summary_fields(z,c("proposed_ISE","averaged_ISE","excess_loss","auxiliary_energy",
      "identity_residual","one_over_B_reference","scaling_residual"))
    ans$fraction_proposed_lower<-mean(z$averaged_ISE>z$proposed_ISE);ans
  })
  decomposition<-do.call(rbind,lapply(state$coefficient_sums,function(z) {
    do.call(rbind,lapply(ctx$methods,function(m) {
      a<-accuracy[accuracy$model==z$model & accuracy$n==z$n & accuracy$method==m & tars_primary(accuracy$c,cfg),]
      bias2<-unname(tars_error(z$sum[[m]]/z$count,ctx$truth[[z$model]]$targetG,ctx)["ISE"])

      data.frame(model=z$model,n=z$n,c=cfg$main_bandwidth_c,method=m,completed=z$count,
        empirical_squared_bias=bias2,empirical_integrated_variance=a$ISE_mean-bias2,MISE=a$ISE_mean)
    }))
  }))
  truth_summary<-do.call(rbind,lapply(ctx$truth,function(t)data.frame(model=t$model$id,
    categories=length(t$model$p),marginal_collision_probability=sum(t$model$p^2),
    population_omission_floor=sum(t$D^2)/(2*pi),spectral_tail_bound=t$spectral_tail_bound)))
  list(accuracy=accuracy,paired=paired,risk=risk,correction=correction,structure=structure,
    averaging=averaging,bias_variance=decomposition,truth=truth_summary)
}

tars_models <- function() {
  C <- matrix(0, 3, 3)
  C[cbind(1:3, c(2, 3, 1))] <- 1
  out <- list(
    IID = list(id = "IID", label = "Independent categories", type = "iid",
               p = c(0.2, 0.5, 0.3)),
    Binary = list(id = "Binary", label = "Binary Markov", type = "markov",
                  p = c(0.75, 0.25),
                  P = matrix(c(0.9, 0.1, 0.3, 0.7), 2, byrow = TRUE)),
    Cyclic = list(id = "Cyclic", label = "Cyclic Markov", type = "markov",
                  p = rep(1/3, 3), P = 0.15 * diag(3) + 0.75 * C + 0.10/3)
  )
  for (s in c(3, 5, 9)) {
    id <- paste0("Gaussian", s)
    out[[id]] <- list(id = id, label = paste("Gaussian AR(2),", s, "categories"),
                      type = "gaussian", p = rep(1/s, s), r = 0.8, w0 = pi/3)
  }
  out
}

tars_K <- function(tau) outer(tau, tau, pmin) - tcrossprod(tau)

tars_scores <- function(p, tau) {
  right <- cumsum(p)
  left <- right - p
  a <- outer(left, tau, function(x, y) y - x)
  positive <- p > 0
  a[positive, ] <- a[positive, , drop = FALSE] / p[positive]
  if (any(!positive)) {
    a[!positive, ] <- outer(right[!positive], tau, "<=")
  }
  a[a < 0] <- 0
  a[a > 1] <- 1
  a
}

tars_Tindex <- function(d) as.vector(t(matrix(seq_len(d*d), d, d)))

tars_spectrum <- function(G, omega, weights = rep(1, ncol(G))) {
  d <- as.integer(sqrt(nrow(G)))
  stopifnot(d*d == nrow(G), length(weights) == ncol(G))
  keep <- which(weights != 0 & seq_along(weights) > 1L)
  F <- matrix(G[, 1L] * weights[1L], d*d, length(omega)) + 0i
  if (length(keep)) {
    B <- sweep(G[, keep, drop = FALSE], 2L, weights[keep], "*")
    Bt <- B[tars_Tindex(d), , drop = FALSE]
    ang <- outer(keep - 1L, omega)
    F <- F + (B + Bt) %*% cos(ang) + 1i * (Bt - B) %*% sin(ang)
  }
  F / (2*pi)
}

tars_lags <- function(Z, max_lag) {
  Z <- as.matrix(Z)
  n <- nrow(Z)
  d <- ncol(Z)
  G <- matrix(0, d*d, max_lag + 1L)
  for (h in 0:max_lag) {

    G[, h + 1L] <- as.vector(crossprod(Z[(h + 1L):n, , drop = FALSE],
                                     Z[seq_len(n - h), , drop = FALSE]) / n)
  }
  G
}

tars_window <- function(G, L, correction = NULL) {
  E <- sweep(G[, seq_len(L), drop = FALSE], 2L, 1 - (0:(L - 1L))/L, "*")
  if (!is.null(correction)) E[, 1L] <- E[, 1L] + as.vector(correction)
  E
}

tars_add_D <- function(F, D) F + as.vector(D)/(2*pi)

tars_tail_lag <- function(vsum, rate, multiplier, cfg, min_lag) {
  if (vsum == 0 || rate == 0) return(list(H = min_lag, bound = 0))
  if (rate >= 1) stop("No geometric covariance-tail bound for this model.")
  H <- max(min_lag, ceiling(log(cfg$truth_tolerance * pi * (1 - rate) /
                                 (vsum * multiplier)) / log(rate) - 1))
  if (H > cfg$truth_max_lag) stop("Increase truth_max_lag to meet truth_tolerance.")
  list(H = as.integer(H), bound = vsum * multiplier * rate^(H + 1)/(pi * (1 - rate)))
}

tars_normal_indicator_cov <- function(a, b, rho) {
  if (abs(rho) < 1e-9) return(rho * dnorm(a) * dnorm(b))
  sg <- sign(rho)
  fun <- function(u) {
    v <- sg*u
    exp(-(a*a - 2*v*a*b + b*b)/(2*(1 - v*v))) / (2*pi*sqrt(1 - v*v))
  }
  sg * stats::integrate(fun, 0, abs(rho), rel.tol = 1e-9,
                        abs.tol = 1e-14, subdivisions = 150L,
                        stop.on.error = TRUE)$value
}

tars_truth <- function(model, cfg, omega, min_lag) {
  p <- model$p
  s <- length(p)
  d <- length(cfg$tau)
  a <- tars_scores(p, cfg$tau)
  A <- sweep(a, 2L, cfg$tau, "-")
  G0 <- crossprod(A, A * p)
  D <- tars_K(cfg$tau) - G0
  if (model$type == "iid") {
    tail <- list(H = min_lag, bound = 0)
  } else if (model$type == "markov") {
    S <- diag(sqrt(p)) %*% model$P %*% diag(1/sqrt(p))
    rate <- norm(S - tcrossprod(sqrt(p)), "2")
    tail <- tars_tail_lag(sum(diag(G0)), rate, 1, cfg, min_lag)
  } else {
    phi <- c(2*model$r*cos(model$w0), -model$r^2)
    rho1 <- phi[1L]/(1 - phi[2L])
    b <- (rho1/model$r - cos(model$w0))/sin(model$w0)
    tail <- tars_tail_lag(sum(diag(G0)), model$r, sqrt(1 + b*b), cfg, min_lag)
  }
  H <- tail$H
  G <- matrix(0, d*d, H + 1L)
  G[, 1L] <- as.vector(G0)
  if (model$type == "markov") {
    Ph <- diag(s)
    for (h in seq_len(H)) {
      Ph <- Ph %*% model$P
      J <- t(sweep(Ph, 1L, p, "*"))
      G[, h + 1L] <- as.vector(crossprod(A, J %*% A))
    }
  } else if (model$type == "gaussian") {
    cuts <- qnorm(cumsum(p)[-s])
    Q <- a[-s, , drop = FALSE] - a[-1L, , drop = FALSE]
    rho <- numeric(H + 1L)
    rho[1:2] <- c(1, rho1)
    if (H >= 2L) for (h in 2:H) rho[h + 1L] <- phi[1L]*rho[h] + phi[2L]*rho[h - 1L]
    for (h in seq_len(H)) {
      B <- matrix(0, s - 1L, s - 1L)
      for (j in seq_len(s - 1L)) for (k in j:(s - 1L)) {
        B[j, k] <- B[k, j] <- tars_normal_indicator_cov(cuts[j], cuts[k], rho[h + 1L])
      }
      G[, h + 1L] <- as.vector(crossprod(Q, B %*% Q))
    }
    model$phi <- phi
    model$rho1 <- rho1
    model$innovation_sd <- sqrt(1 - phi[1L]*rho1 - phi[2L]*rho[3L])
    model$cuts <- cuts
  }
  fA <- tars_spectrum(G, omega)
  targetG <- G
  targetG[, 1L] <- targetG[, 1L] + as.vector(D)
  list(model = model, scores = a, A = A, D = D, G = G, targetG = targetG,
       fA = fA, f = tars_add_D(fA, D), H = H,
       spectral_tail_bound = tail$bound)
}

tars_sample <- function(model, n) {
  s <- length(model$p)
  if (model$type == "iid") return(sample.int(s, n, replace = TRUE, prob = model$p))
  if (model$type == "markov") {
    x <- integer(n)
    x[1L] <- sample.int(s, 1L, prob = model$p)
    cp <- t(apply(model$P, 1L, cumsum))
    u <- runif(n - 1L)
    for (i in 2:n) x[i] <- 1L + sum(u[i - 1L] > cp[x[i - 1L], -s])
    return(x)
  }

  w <- numeric(n)
  w[1L] <- rnorm(1L)
  w[2L] <- model$rho1*w[1L] + sqrt(1 - model$rho1^2)*rnorm(1L)
  e <- rnorm(n - 2L, sd = model$innovation_sd)
  for (i in 3:n) w[i] <- model$phi[1L]*w[i - 1L] + model$phi[2L]*w[i - 2L] + e[i - 2L]
  findInterval(w, model$cuts) + 1L
}

tars_error <- function(E, target, ctx) {

  H <- max(ncol(E), ncol(target))
  B <- matrix(0, nrow(E), H)
  B[, seq_len(ncol(E))] <- E
  B[, seq_len(ncol(target))] <- B[, seq_len(ncol(target)), drop = FALSE] - target
  w <- c(1, rep(2, H - 1L))/(2*pi)
  diag_error <- as.numeric((B[ctx$diag_index, , drop = FALSE]^2) %*% w)
  Tidx <- tars_Tindex(ctx$d)
  S <- (B + B[Tidx, , drop = FALSE])/2
  A <- (B - B[Tidx, , drop = FALSE])/2
  real_cross <- sum(as.numeric((S[ctx$offdiag_index, , drop = FALSE]^2) %*% w))
  imag_cross <- sum(as.numeric((A[ctx$offdiag_index, , drop = FALSE]^2) %*% w))
  c(ISE = sum((B^2) %*% w), diagonal = sum(diag_error),
    real_cross = real_cross, imag_cross = imag_cross,
    setNames(diag_error, paste0("D", seq_len(ctx$d))))
}

tars_min_eigen <- function(F, d) {
  min(vapply(seq_len(ncol(F)), function(i)
    min(Re(eigen(matrix(F[, i], d, d), symmetric = TRUE, only.values = TRUE)$values)), numeric(1)))
}

tars_component <- function(F, components, columns) {
  z <- F[components$index, columns, drop = FALSE]
  ans <- Re(z)
  ii <- components$part == "imag"
  ans[ii, ] <- Im(z[ii, , drop = FALSE])
  ans
}

tars_worker <- function(job, ctx) {
  assign(".Random.seed", job$rng, envir = .GlobalEnv)
  tryCatch(list(ok = TRUE, id = job$id, result = tars_job(job, ctx)),
           error = function(e) list(ok = FALSE, id = job$id, message = conditionMessage(e),
                                    rng = job$rng, job = job))
}

tars_mean <- function(x) if (any(is.finite(x))) mean(x[is.finite(x)]) else NA_real_

tars_mcse <- function(x) {
  x <- x[is.finite(x)]
  if (length(x) >= 2L) sd(x)/sqrt(length(x)) else NA_real_
}

tars_group <- function(dat, keys, fun) {
  tag <- do.call(paste, c(lapply(dat[keys], as.character), sep = "\r"))
  out <- lapply(split(seq_len(nrow(dat)), tag), function(ii) {
    x <- dat[ii, , drop = FALSE]
    cbind(x[1L, keys, drop = FALSE], as.data.frame(fun(x)), row.names = NULL)
  })
  ans <- do.call(rbind, out)
  rownames(ans) <- NULL
  ans
}

tars_bind_records <- function(state, slot) {
  ans <- do.call(rbind, lapply(state$records, `[[`, slot))
  rownames(ans) <- NULL
  ans
}

tars_tex_table <- function(path, header, rows, caption, label, align = NULL) {
  if (is.null(align)) align <- paste0("l", paste(rep("r", length(header) - 1L), collapse = ""))
  lines <- c("\\begin{table}[t]", "\\centering", "\\small", "\\setlength{\\tabcolsep}{3pt}",
             paste0("\\caption{", caption, "}"), paste0("\\label{", label, "}"),
             paste0("\\begin{tabular}{", align, "}"), "\\hline",
             paste0(paste(header, collapse = " & "), " \\\\"), "\\hline",
             apply(rows, 1L, function(x) paste0(paste(x, collapse = " & "), " \\\\")),
             "\\hline", "\\end{tabular}", "\\end{table}")
  writeLines(lines, path, useBytes = TRUE)
}

tars_fmt <- function(x, digits = 3L) {
  ifelse(is.finite(x), formatC(x, digits = digits, format = "f"), "--")
}

tars_fmt_se <- function(m, se, scale = 1) {
  paste0(tars_fmt(scale*m), " (", tars_fmt(scale*se), ")")
}

tars_colors <- function() {
  c(Proposed = "#0072B2", Randomized = "#E69F00", `Average-rank` = "#CC79A7",
    `Upper-rank` = "#666666", `No-correction` = "#D55E00", Oracle = "#009E73",
    Truth = "black")
}

tars_pdf <- function(file, panel_fun, n_panels = 6L, legend_labels = NULL,
                     legend_colors = NULL, legend_lty = NULL, legend_pch = NULL) {
  ncol <- if (n_panels == 1L) 1L else if (n_panels <= 4L) 2L else 3L
  nrow <- ceiling(n_panels/ncol)
  if (isTRUE(capabilities("cairo"))) {
    grDevices::cairo_pdf(file, width = if (ncol == 3L) 11.4 else 8,
                         height = 3.5*nrow + 0.7, family = "sans", onefile = TRUE)
  } else {
    grDevices::pdf(file, width = if (ncol == 3L) 11.4 else 8,
                   height = 3.5*nrow + 0.7, family = "Helvetica", useDingbats = FALSE)
  }
  on.exit(grDevices::dev.off(), add = TRUE)
  graphics::par(mfrow = c(nrow, ncol), mar = c(4.1, 5.8, 2.5, 0.8),
                oma = c(if (is.null(legend_labels)) 0.3 else 3.8, 0, 0, 0),
                mgp = c(2.5, 0.7, 0), cex = 0.85, las = 1)
  for (i in seq_len(n_panels)) panel_fun(i)
  if (!is.null(legend_labels)) {
    graphics::par(fig = c(0, 1, 0, 1), oma = rep(0, 4), mar = rep(0, 4),
                  new = TRUE, xpd = NA)
    graphics::plot.new()
    graphics::plot.window(xlim = c(0, 1), ylim = c(0, 1))
    graphics::legend("bottom", legend_labels, col = legend_colors, lty = legend_lty,
                      pch = legend_pch, ncol = min(4L, length(legend_labels)), bty = "n",
                      cex = 0.95, inset = 0.01, x.intersp = 0.7, seg.len = 2)
  }
}

tars_ytitle <- function(label) graphics::mtext(label, side = 2, line = 4.15, las = 0)

tars_save <- function(state, path, compress = FALSE) {
  tmp <- paste0(path, ".tmp")
  backup <- paste0(path, ".previous")
  saveRDS(state, tmp, compress = compress)
  if (file.exists(path)) {
    if (file.exists(backup)) unlink(backup)
    if (!file.rename(path, backup)) stop("Cannot rotate the checkpoint: ", path)
  }
  if (!file.rename(tmp, path)) {
    if (file.exists(backup)) file.rename(backup, path)
    stop("Cannot install the new checkpoint: ", path)
  }
  if (file.exists(backup)) unlink(backup)
  invisible(NULL)
}

tars_read <- function(path) {
  backup <- paste0(path, ".previous")
  if (!file.exists(path) && file.exists(backup)) return(readRDS(backup))
  tryCatch(readRDS(path), error = function(e) {
    if (file.exists(backup)) readRDS(backup) else stop(e)
  })
}

tars_self_check <- function() {
  tau <- c(.2, .4, .55, .85)
  x <- c(1L, 1L, 2L, 3L, 3L)
  n <- length(x)
  d <- length(tau)
  p <- tabulate(x)/n
  a <- tars_scores(p, tau)
  Z <- sweep(a[x, , drop = FALSE], 2L, tau, "-")
  D <- tars_K(tau) - crossprod(Z)/n
  L <- 3L
  omega <- c(.2, .9, 2.0)
  G <- tars_window(tars_lags(Z, L - 1L), L, D)
  F <- tars_spectrum(G, omega)
  left <- cumsum(p) - p
  outcomes <- lapply(x, function(k) {
    b <- sort(unique(c(0, 1, a[k, ])))
    list(prob = diff(b), y = sweep(outer(left[k] + p[k]*(head(b, -1L) + tail(b, -1L))/2,
                                       tau, "<="), 2L, tau, "-"))
  })
  idx <- do.call(expand.grid, lapply(outcomes, function(z) seq_along(z$prob)))
  EF <- F*0
  Erisk <- 0
  Eaux <- 0
  target <- matrix(as.vector(tars_K(tau)/(2*pi)), d*d, length(omega))
  for (r in seq_len(nrow(idx))) {
    rr <- as.integer(idx[r, ])
    pr <- prod(vapply(seq_len(n), function(t) outcomes[[t]]$prob[rr[t]], numeric(1)))
    Y <- do.call(rbind, lapply(seq_len(n), function(t) outcomes[[t]]$y[rr[t], ]))
    FY <- tars_spectrum(tars_window(tars_lags(Y, L - 1L), L), omega)
    EF <- EF + pr*FY
    Erisk <- Erisk + pr*sum(Mod(FY - target)^2)
    Eaux <- Eaux + pr*sum(Mod(FY - F)^2)
  }
  Q <- 1 - abs(outer(seq_len(n), seq_len(n), "-"))/L
  Q[Q < 0] <- 0
  direct <- sapply(omega, function(w) {
    e <- exp(-1i*w*seq_len(n))
    as.vector(t(Z) %*% (Q*tcrossprod(e, Conj(e))) %*% Z/(2*pi*n) + D/(2*pi))
  })
  checks <- c(conditional_mean = max(Mod(EF - F)),
               risk_identity = abs(Erisk - sum(Mod(F - target)^2) - Eaux),
               direct_quadratic_form = max(Mod(direct - F)),
               normalization = max(abs(G[, 1L] - as.vector(tars_K(tau)))),
               score_mean = max(abs(colMeans(Z))))
  if (max(checks) > 1e-10) stop("An algebraic self-check failed: ", paste(checks, collapse = ", "))
  checks
}

tars_write_tables <- function(state,folder) {
  dir.create(folder,recursive=TRUE,showWarnings=FALSE)
  tb<-state$tables;cfg<-state$config;methods<-state$context$methods
  for(nm in names(tb)) write.csv(tb[[nm]],file.path(folder,paste0("table_",nm,".csv")),row.names=FALSE,na="")
  rows<-list();k<-0L
  for(model in cfg$models) for(n in cfg$n) {
    k<-k+1L;z<-tb$accuracy[tb$accuracy$model==model & tb$accuracy$n==n & tars_primary(tb$accuracy$c,cfg),]
    z<-z[match(methods,z$method),]
    rows[[k]]<-c(model,n,tars_fmt_se(z$ISE_mean,z$ISE_mcse,1000))
  }
  band<-paste0("$L=\\lfloor ",cfg$main_bandwidth_c,"n^{1/3}\\rfloor$")
  tars_tex_table(file.path(folder,"table_1_accuracy.tex"),c("Model","$n$",methods),do.call(rbind,rows),
    paste0("Mean integrated squared Frobenius error multiplied by $10^3$, with Monte Carlo standard errors in parentheses. All methods use ",band,
      ". Oracle uses the population marginal distribution. Average-rank and Upper-rank are tie-handling benchmarks evaluated against the same randomized-transform target."),"tab:tars-accuracy")
  r<-tb$risk[tb$risk$n==max(cfg$n) & tars_primary(tb$risk$c,cfg),]
  r<-r[match(cfg$models,r$model),]
  rows<-cbind(r$model,tars_fmt_se(r$paired_gain_mean,r$paired_gain_mcse,1000),
    tars_fmt_se(r$auxiliary_energy_mean,r$auxiliary_energy_mcse,1000),
    tars_fmt_se(r$decomposition_residual_mean,r$decomposition_residual_mcse,1000))
  tars_tex_table(file.path(folder,"table_2_risk_decomposition.tex"),
    c("Model","Risk difference","Auxiliary variation","Residual"),rows,
    paste0("Randomized minus proposed error at $n=",max(cfg$n),"$ and ",band,
      ". Auxiliary variation is the integrated squared distance between the two estimates. The residual is the risk difference minus auxiliary variation. Entries and Monte Carlo standard errors are multiplied by $10^3$."),"tab:tars-risk")
  a<-tb$correction[tb$correction$n==max(cfg$n) & tars_primary(tb$correction$c,cfg),]
  a<-a[match(cfg$models,a$model),]
  rows<-cbind(a$model,tars_fmt_se(a$proposed_ISE_mean,a$proposed_ISE_mcse,1000),
    tars_fmt_se(a$uncorrected_ISE_mean,a$uncorrected_ISE_mcse,1000),
    tars_fmt_se(a$removed_error_mean,a$removed_error_mcse,1000),tars_fmt(1000*a$correction_energy_mean))
  tars_tex_table(file.path(folder,"table_3_zero_lag.tex"),
    c("Model","Proposed","No-correction","Error removed","Correction energy"),rows,
    paste0("Zero-lag ablation at $n=",max(cfg$n),"$ and ",band,
      ". Values are multiplied by $10^3$; parentheses give Monte Carlo standard errors. For each replication, the removed error equals $\\|\\widehat D\\|_F^2/(2\\pi)$."),"tab:tars-zero-lag")
  a<-tb$averaging;a<-a[order(match(a$model,cfg$models),a$B),]
  rows<-cbind(a$model,a$B,tars_fmt_se(a$averaged_ISE_mean,a$averaged_ISE_mcse,1000),
    tars_fmt_se(a$proposed_ISE_mean,a$proposed_ISE_mcse,1000),
    tars_fmt_se(a$auxiliary_energy_mean,a$auxiliary_energy_mcse,1000))
  tars_tex_table(file.path(folder,"table_4_randomization_averaging.tex"),
    c("Model","$B$","Randomized average","Proposed","Auxiliary variation"),rows,
    paste0("Averages of $B$ independently randomized spectral estimates on each fixed data series, with $n=",cfg$mechanism_n,"$ and ",band,
      ". The same empirical marginal is used for every randomization. Entries are mean integrated squared errors or distances, multiplied by $10^3$, with Monte Carlo standard errors across independent data series."),"tab:tars-averaging")
}

tars_plot_ise <- function(state,folder) {
  cfg<-state$config;tb<-state$tables$accuracy;colors<-tars_colors();methods<-state$context$methods
  tars_pdf(file.path(folder,"figure_1_MISE.pdf"),function(i) {
    model<-cfg$models[i];z<-tb[tb$model==model & tars_primary(tb$c,cfg),]
    yr<-range(z$ISE_mean[z$ISE_mean>0]);yr<-yr*c(.8,1.2)
    xr<-range(cfg$n);if(diff(xr)==0)xr<-xr*c(.9,1.1)
    plot(xr,yr,type="n",log="xy",xaxt="n",xlab="Sample size",ylab="",main=model)
    tars_ytitle("Mean integrated squared error");axis(1,at=cfg$n,labels=cfg$n)
    for(m in seq_along(methods)) {
      a<-z[z$method==methods[m],];a<-a[order(a$n),]
      lines(a$n,a$ISE_mean,col=colors[methods[m]],lty=m,lwd=if(m==1)2.2 else 1.3)
      points(a$n,a$ISE_mean,col=colors[methods[m]],pch=14L+m,cex=.75)
    }
  },length(cfg$models),methods,colors[methods],seq_along(methods),14L+seq_along(methods))
}

tars_plot_averaging <- function(state,folder) {
  tb<-state$tables$averaging;cfg<-state$config
  tars_pdf(file.path(folder,"figure_2_conditional_averaging.pdf"),function(i) {
    z<-tb[tb$model==cfg$models[i],];z<-z[order(z$B),]
    low<-pmax(z$auxiliary_energy_mean-z$auxiliary_energy_mcse, .Machine$double.eps)
    high<-z$auxiliary_energy_mean+z$auxiliary_energy_mcse
    yr<-range(c(low,high,z$one_over_B_reference_mean));yr<-yr*c(.8,1.2)
    plot(range(z$B),yr,type="n",log="xy",xaxt="n",xlab="Number of randomizations B",ylab="",main=cfg$models[i])
    tars_ytitle("Mean squared distance from Proposed")
    axis(1,at=z$B,labels=z$B)
    lines(z$B,z$one_over_B_reference_mean,col="#666666",lty=2,lwd=1.6)
    arrows(z$B,low,z$B,high,angle=90,code=3,length=.025,col="#0072B2")
    lines(z$B,z$auxiliary_energy_mean,type="b",pch=16,col="#0072B2",lwd=1.7)
  },length(cfg$models),c("Empirical distance (1 MCSE bars)","1/B reference"),
    c("#0072B2","#666666"),c(1,2),c(16,NA))
}

tars_panel_specs <- function(state) {
  ctx<-state$context;tau<-ctx$cfg$tau
  pick<-function(a,b,part) {
    j<-which.min(abs(tau-a));k<-which.min(abs(tau-b))
    ii<-which(ctx$components$j==j & ctx$components$k==k & ctx$components$part==part)
    if(length(ii))ii[1] else 1L
  }
  specs<-data.frame(model=c("IID","Binary","Cyclic","Cyclic","Gaussian3","Gaussian9"),
    component=c(pick(.5,.5,"real"),pick(.75,.75,"real"),pick(.25,.75,"real"),
      pick(.25,.75,"imag"),pick(.5,.5,"real"),pick(.5,.5,"real")))
  specs<-specs[specs$model %in% ctx$cfg$models,]
  if(!nrow(specs)) specs<-data.frame(model=ctx$cfg$models,component=pick(.5,.5,"real"))
  specs
}

tars_plot_spectra <- function(state,folder) {
  ctx<-state$context;specs<-tars_panel_specs(state);methods<-c("Proposed","No-correction","Randomized")
  colors<-tars_colors()
  tars_pdf(file.path(folder,"figure_3_mean_spectra.pdf"),function(i) {
    model<-specs$model[i];comp<-specs$component[i];cpt<-ctx$components[comp,];agg<-state$curves[[model]]
    truth<-tars_component(ctx$truth[[model]]$f,ctx$components,seq_along(ctx$omega))[comp,]
    curves<-lapply(methods,function(m)agg$sum[[m]][comp,]/agg$count)
    yr<-range(c(truth,unlist(curves)));if(diff(yr)<1e-10)yr<-yr+c(-.01,.01)
    title<-paste0(model,": ",if(cpt$part=="imag")"Im " else "Re ","(",cpt$tau_j,", ",cpt$tau_k,")")
    plot(ctx$omega/pi,truth,type="l",col="black",lwd=2,ylim=yr,xlab=expression(omega/pi),ylab="",main=title)
    tars_ytitle("Spectral ordinate")

    for(m in rev(seq_along(methods))) lines(ctx$omega/pi,curves[[m]],col=colors[methods[m]],lty=m+1L,lwd=1.6)
  },nrow(specs),c("Truth",methods),colors[c("Truth",methods)],1:4)
}

tars_plot_gain <- function(state,folder) {
  cfg<-state$config;tb<-state$tables$accuracy;cols<-grDevices::hcl.colors(length(cfg$n),"Dark 3")
  tars_pdf(file.path(folder,"figure_4_quantile_gain.pdf"),function(i) {
    model<-cfg$models[i];gain<-matrix(NA_real_,length(cfg$tau),length(cfg$n))
    for(k in seq_along(cfg$n)) {
      z<-tb[tb$model==model & tb$n==cfg$n[k] & tars_primary(tb$c,cfg),]
      names<-paste0("D",seq_along(cfg$tau),"_mean")
      a<-as.numeric(z[z$method=="Randomized",names]);b<-as.numeric(z[z$method=="Proposed",names])
      gain[,k]<-100*(1-b/a)
    }
    yr<-range(c(0,gain),finite=TRUE);if(diff(yr)<1e-8)yr<-yr+c(-1,1)
    plot(range(cfg$tau),yr,type="n",xlab=expression(tau),ylab="",main=model)
    tars_ytitle("Diagonal MISE reduction (%)");abline(h=0,col="gray60",lty=3)
    for(k in seq_along(cfg$n))lines(cfg$tau,gain[,k],type="b",pch=14L+k,lty=k,lwd=1.5,col=cols[k])
  },length(cfg$models),paste0("n = ",cfg$n),cols,seq_along(cfg$n),14L+seq_along(cfg$n))
}

tars_plot_bandwidth <- function(state,folder) {
  cfg<-state$config;tb<-state$tables$accuracy;colors<-tars_colors();methods<-state$context$methods
  tars_pdf(file.path(folder,"figure_5_bandwidth_sensitivity.pdf"),function(i) {
    model<-cfg$models[i];z<-tb[tb$model==model & tb$n==max(cfg$n),]
    yr<-range(z$ISE_mean[z$ISE_mean>0])*c(.8,1.2)
    xr<-range(cfg$bandwidth_c);if(diff(xr)==0)xr<-xr*c(.8,1.2)
    plot(xr,yr,type="n",log="y",xaxt="n",xlab="Bandwidth multiplier c",ylab="",main=model)
    tars_ytitle("Mean integrated squared error");axis(1,at=cfg$bandwidth_c)
    abline(v=cfg$main_bandwidth_c,col="gray80",lty=3)
    for(m in seq_along(methods)) {
      a<-z[z$method==methods[m],];a<-a[order(a$c),]
      lines(a$c,a$ISE_mean,type="b",col=colors[methods[m]],lty=m,pch=14L+m,lwd=if(m==1)2 else 1.3)
    }
  },length(cfg$models),methods,colors[methods],seq_along(methods),14L+seq_along(methods))
}

tars_plot_ties <- function(state,folder) {
  cfg<-state$config;ids<-intersect(c("Gaussian3","Gaussian5","Gaussian9"),cfg$models)
  if(length(ids)<2L)return(invisible(NULL))
  paired<-state$tables$paired;correction<-state$tables$correction
  s<-vapply(ids,function(m)length(state$context$truth[[m]]$model$p),integer(1))
  cols<-grDevices::hcl.colors(length(cfg$n),"Dark 3")
  tars_pdf(file.path(folder,"figure_6_tie_resolution.pdf"),function(panel) {
    y<-matrix(NA_real_,length(ids),length(cfg$n))
    for(i in seq_along(ids)) for(k in seq_along(cfg$n)) {
      if(panel==1L) {
        a<-paired[paired$model==ids[i] & paired$n==cfg$n[k] & paired$comparator=="Randomized" & tars_primary(paired$c,cfg),]
        y[i,k]<-100*a$relative_reduction
      } else {
        a<-correction[correction$model==ids[i] & correction$n==cfg$n[k] & tars_primary(correction$c,cfg),]
        y[i,k]<-100*a$removed_error_mean/a$uncorrected_ISE_mean
      }
    }
    yr<-range(c(0,y),finite=TRUE);if(diff(yr)<1e-8)yr<-yr+c(-1,1)
    plot(range(s),yr,type="n",xaxt="n",xlab="Number of categories",ylab="",
      main=if(panel==1L)"Auxiliary randomization" else "Zero-lag correction")
    tars_ytitle(if(panel==1L)"MISE reduction versus Randomized (%)" else "MISE reduction versus No-correction (%)")
    axis(1,at=s);abline(h=0,col="gray70",lty=3)
    for(k in seq_along(cfg$n))lines(s,y[,k],type="b",col=cols[k],lty=k,pch=14L+k,lwd=1.6)
  },2L,paste0("n = ",cfg$n),cols,seq_along(cfg$n),14L+seq_along(cfg$n))
}

tars_export <- function(state) {
  folder<-state$config$output_dir
  tars_write_tables(state,file.path(folder,"tables"))
  fig<-file.path(folder,"figures");dir.create(fig,recursive=TRUE,showWarnings=FALSE)
  tars_plot_ise(state,fig);tars_plot_averaging(state,fig);tars_plot_spectra(state,fig)
  tars_plot_gain(state,fig);tars_plot_bandwidth(state,fig);tars_plot_ties(state,fig)
  invisible(NULL)
}

tars_run <- function(cfg = CFG) {
  cfg <- tars_validate(cfg)
  checks <- tars_self_check()
  dir.create(cfg$output_dir, recursive = TRUE, showWarnings = FALSE)
  cfg$output_dir <- normalizePath(cfg$output_dir, winslash = "/", mustWork = TRUE)
  file <- file.path(cfg$output_dir, "TARS_point_results.rds")
  signature <- tars_signature(cfg)
  if (file.exists(file) || file.exists(paste0(file, ".previous"))) {
    if (!isTRUE(cfg$resume)) stop("The output directory already contains results. Use a new output_dir or resume = TRUE.")
    state <- tars_read(file)
    if (!identical(state$signature, signature)) stop("The saved design differs from CFG. Use a new output_dir for the changed design.")
    if (cfg$n_rep < state$config$n_rep || cfg$mechanism_rep < state$config$mechanism_rep) stop("Replication counts cannot be reduced when resuming. Use a new output_dir.")
    state$config <- cfg
    ctx <- state$context
    ctx$cfg <- cfg
    state$context <- ctx
  } else {
    ctx <- tars_prepare(cfg)
    state <- list(engine = tars_engine(), signature = signature, config = cfg,
                  status = "incomplete", context = ctx, records = list(), failures = list(),
                  curves = list(), coefficient_sums = list(), checks = checks, tables = NULL,
                  session = utils::sessionInfo(), started_at = Sys.time())
    tars_save(state, file)
  }
  jobs <- tars_jobs(cfg)
  pending <- jobs[!names(jobs) %in% names(state$records)]
  start <- Sys.time()
  message(length(state$records), " / ", length(jobs), " jobs already saved.")
  if (length(pending)) {
    ncores <- parallel::detectCores(logical = TRUE)
    if (is.na(ncores)) ncores <- 1L
    nw <- min(cfg$workers, ncores, length(pending))
    threads <- c("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")
    oldenv <- Sys.getenv(threads, unset = NA_character_)
    do.call(Sys.setenv, as.list(setNames(rep("1", length(threads)), threads)))
    on.exit({
      keep <- !is.na(oldenv)
      if (any(keep)) do.call(Sys.setenv, as.list(oldenv[keep]))
      if (any(!keep)) Sys.unsetenv(names(oldenv)[!keep])
    }, add = TRUE)
    cl <- NULL
    if (nw > 1L) {
      cl <- parallel::makePSOCKcluster(nw, outfile = "")
      on.exit(parallel::stopCluster(cl), add = TRUE)
      env <- new.env(parent = environment(tars_run))
      env$TARS_CONTEXT <- ctx
      fns <- ls(envir = environment(tars_run), pattern = "^tars_")
      fns <- fns[vapply(mget(fns, envir = environment(tars_run)), is.function, logical(1))]
      parallel::clusterExport(cl, c(fns, "TARS_CONTEXT"), envir = env)
    }
    message("Running with ", nw, " worker(s).")
    chunks <- split(seq_along(pending), ceiling(seq_along(pending)/cfg$checkpoint_every))
    tryCatch({
      for (ii in chunks) {
        batch <- pending[ii]
        ans <- if (is.null(cl)) lapply(batch, tars_worker, ctx = ctx) else
          parallel::parLapplyLB(cl, batch, function(job) tars_worker(job, TARS_CONTEXT))
        failed <- FALSE
        for (a in ans) {
          if (isTRUE(a$ok)) {
            state <- tars_accumulate(state, a$result, jobs[[a$id]])
            a$result$curves <- NULL
            a$result$coefficients <- NULL
            state$records[[a$id]] <- a$result
            state$failures[[a$id]] <- NULL
          } else {
            state$failures[[a$id]] <- a
            failed <- TRUE
          }
        }
        state$status <- if (failed) "failed" else "incomplete"
        state$saved_at <- Sys.time()
        tars_save(state, file)
        elapsed <- as.numeric(difftime(Sys.time(), start, units = "mins"))
        message(sprintf("%d / %d saved; elapsed %.1f min", length(state$records), length(jobs), elapsed))
        if (failed) {
          first <- state$failures[[1L]]
          stop("A replication failed: ", first$id, ": ", first$message,
               "\nSuccessful results and the failed job's RNG state are in TARS_point_results.rds.")
        }
      }
    }, interrupt = function(e) {
      state$status <- "interrupted"
      state$saved_at <- Sys.time()
      tars_save(state, file)
      stop("Interrupted. Saved results can be resumed with the same CFG.", call. = FALSE)
    })
  }
  stopifnot(length(state$records) == length(jobs), !length(state$failures))
  state$status <- "complete"
  state$completed_at <- Sys.time()
  state$tables <- tars_summarize(state)
  state$session <- utils::sessionInfo()
  tars_save(state, file, compress = "gzip")
  tars_export(state)
  message("Complete. Results: ", file)
  invisible(state)
}

if (isTRUE(getOption("TARS.autorun", TRUE))) {
  TARS_RESULT <- tars_run(CFG)
}
